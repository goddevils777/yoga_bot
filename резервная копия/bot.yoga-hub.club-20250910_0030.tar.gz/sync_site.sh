#!/bin/bash
rsync -av --delete /home/ej359436/yoga-hub.club/www/ /home/ej359436/yoga-hub.club/mirror/


