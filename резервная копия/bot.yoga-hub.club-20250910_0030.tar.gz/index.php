<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>YHC</title>
    <meta name="copyright" content="Copyright 1999-2022. Plesk International GmbH. All rights reserved.">
</head>
<body>
<h1>Have a nice Day:)</h1>
<?php 

// Через глобальную переменную $_SERVER
if (isset($_SERVER['DOCUMENT_ROOT'])) {
    //echo $_SERVER['DOCUMENT_ROOT'];
} else {
    //echo "Скрипт запущен не через веб-сервер";
}

?>
</body>
</html>
